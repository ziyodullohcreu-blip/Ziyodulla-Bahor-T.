# Ziyodulla & Bahor — to'y taklifnomasi

Bu papkada saytning barcha fayllari bor:

- `index.html` — asosiy sahifa
- `hero.jpg` — fon surat
- `music.mp3` — fon musiqa

## GitHub Pages orqali joylashtirish (bepul, hammaga ko'rinadi)

1. https://github.com ga kiring, o'ng yuqoridagi **+** tugmasidan **New repository** ni tanlang.
2. Repo nomini yozing, masalan `wedding-invitation`, **Public** qilib qoldiring, **Create repository** tugmasini bosing.
3. Ochilgan sahifada **"uploading an existing file"** havolasini bosing (yoki repo ichida **Add file → Upload files**).
4. Shu papkadagi 3 ta faylni (`index.html`, `hero.jpg`, `music.mp3`) sudrab tashlang yoki tanlab yuklang.
5. Pastda **Commit changes** tugmasini bosing.
6. Repo sahifasida **Settings** bo'limiga o'ting, chap tomondagi menyudan **Pages** ni tanlang.
7. **Build and deployment → Source** qismida **Deploy from a branch** ni tanlang, **Branch: main / (root)** qilib **Save** bosing.
8. Bir necha daqiqadan so'ng shu sahifada havola paydo bo'ladi:
   `https://<foydalanuvchi-nomingiz>.github.io/wedding-invitation/`

Shu havolani istalgan odamga yuborishingiz mumkin — u hech qanday hisobga kirmasdan ochib ko'ra oladi.

## RSVP haqida eslatma

Bu statik sahifa bo'lgani uchun (server yo'q), "Javob bering" formasi mehmonning javobini avtomatik saqlamaydi. Forma "Xabar tayyorlash" tugmasi bosilganda tayyor matnni ko'rsatadi — mehmon uni nusxalab, sizga Telegram yoki WhatsApp orqali yuborishi kerak.

Agar xohlasangiz, keyinroq buni haqiqiy avtomatik RSVP (masalan Google Forms yoki Telegram bot) bilan bog'lab berishim mumkin.
